using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Bird : MonoBehaviour
{
    Rigidbody2D rb2d;
    public float Speed = 5f;
    private float flapforce = 100f;
    bool isDead;
    public GameObject ReplayButton;
    int Score = 0;
    public Text scoreText;

    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 0;
        rb2d = GetComponent<Rigidbody2D>();
        //Go right
        rb2d.velocity = Vector2.right * Speed * Time.deltaTime;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0) && !isDead)
        {
            rb2d.velocity = Vector2.right * Speed * Time.deltaTime;
            rb2d.AddForce(Vector2.up * flapforce);
        }
    }
    private void OnCollisionEnter2D(Collision2D col)
    {
        isDead = true;
        rb2d.velocity = Vector2.zero;
        ReplayButton.SetActive(true);
        GetComponent<Animator>().GetBool("isDead,True");
        ReplayButton.SetActive(true);
    }
    public void Replay()
    {
        SceneManager.LoadScene(0);
    }
    public void UnFreeze()
    {
        Time.timeScale = 1;

    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag== "Score")
        {
            Score++;
            Debug.Log(Score);
        }
        scoreText.text = Score.ToString();

    }
}
